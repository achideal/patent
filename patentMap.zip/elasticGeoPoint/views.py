from django.shortcuts import render, HttpResponse
import json

# Create your views here.
from elasticGeoPoint import elastic, dslPolygon, dslOnePoint, contentDiv


def getGeoBox(request):
    coords = None
    para = {}
    if request.GET['coords_global']:
        coords = request.GET['coords_global']
        if coords == '0':
            print("sssssssssss")
            return render(request, "elasticGeoPoint/geoBox_initial.html")
        para["coords"] = json.dumps(coords,ensure_ascii=False)
    coords = json.loads(coords) #将Json string 转换为 dict
    flagOrPoint = coords['geometry']['coordinates'][0]

    if flagOrPoint == "onePoint":#查询一个点对应的专利清单
        onePoint = coords['geometry']['coordinates'][1]
        dslOnePoint["from"] = 0
        dslOnePoint["query"]["bool"]["filter"]["geo_distance"]["locations.location"] = onePoint
        result = elastic.search(index='.ent-search-engine-documents-patent', body=dslOnePoint)
    else:
        points = flagOrPoint
        #对获取的geoJson从elasticsearch拿数据
        dslPolygon["from"] = 0 #从第0个编号开始
        dslPolygon["query"]["bool"]["filter"]["geo_polygon"]["locations.location"]["points"] = points
        result = elastic.search(index='.ent-search-engine-documents-patent', body=dslPolygon)
    elasticDocuments = result['hits']['hits'] #获取elastic的documents
    itemNum = result['hits']["total"]["value"]

    print(elasticDocuments)

    para["patents"] = elasticDocuments
    para["patents_num"] = len(elasticDocuments)
    para["page_num"] = (itemNum+19) // 20 #向上取整


    return render(request, "elasticGeoPoint/geoBox.html", para)

def pageRefresh(request):
    coords = None
    para = {}
    from_num = 0
    if request.GET['coords_global'] or request.GET['curpage']:
        coords = request.GET['coords_global']
        from_num = (int(request.GET['curpage']) - 1)*20

    coords = json.loads(coords)  # 将Json string 转换为 dict
    flagOrPoint = coords['geometry']['coordinates'][0]
    if flagOrPoint == "onePoint":  # 查询一个点对应的专利清单
        onePoint = coords['geometry']['coordinates'][1]
        dslOnePoint["from"] = from_num
        dslOnePoint["query"]["bool"]["filter"]["geo_distance"]["locations.location"] = onePoint
        result = elastic.search(index='.ent-search-engine-documents-patent', body=dslOnePoint)
    else:
        points = flagOrPoint
        # 对获取的geoJson从elasticsearch拿数据
        dslPolygon["from"] = from_num
        dslPolygon["query"]["bool"]["filter"]["geo_polygon"]["locations.location"]["points"] = points
        result = elastic.search(index='.ent-search-engine-documents-patent', body=dslPolygon)
    elasticDocuments = result['hits']['hits']  # 获取elastic的documents

    para["patents"] = elasticDocuments
    return render(request, "elasticGeoPoint/refresh.html", para)
