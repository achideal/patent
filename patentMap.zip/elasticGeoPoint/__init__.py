from elasticsearch import Elasticsearch

elastic = Elasticsearch(
    ['127.0.0.1'],
    http_auth=('elastic', '4V56BthlDTtmyyFI4n3i'),
    scheme="https",
    port=9200,
    verify_certs=False
)

dslPolygon = {
  "query": {
    "bool": {
      "must": {
        "match_all": {}
      },
     "filter": {
        "geo_polygon": {
          "locations.location": {
            "points": [ ]
          }
        }
      }
    }
  },
  "from": 0,
  "size": 20
}

dslOnePoint = {
  "query": {
    "bool": {
      "must": {
        "match_all": {}
      },
     "filter": {
        "geo_distance": {
          "distance": "200m",
          "locations.location": [-25.6671,37.7463 ]
        }
      }

    }
  },
  "from": 0,
  "size": 20
}


dslClosest = {
  "size": 1,
  "sort" : [
    {
      "_geo_distance" : {
          "locations.location" : [-70, 40],
          "order" : "asc",
          "unit" : "m",
          "mode" : "min",
          "distance_type" : "arc",
          "ignore_unmapped": True
      }
    }
  ],
  "query" : {
    "match_all" : {}
  }
}





print("执行了一次")

contentDiv = '''


'''
