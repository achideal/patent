from django import template
import pandas as pd
import os

path_topic =  r"/mnt/patentMap/elasticGeoPoint/templatetags/topic_source_file/get_topic_info_kmeans.csv"
#path_topic =  r"D:\onedrive\OneDrive - whu.edu.cn\桌面\patentMap\elasticGeoPoint\templatetags\topic_source_file\get_topic_info_kmeans.csv"
topics = pd.read_csv(path_topic).Name.to_list()

register = template.Library()
@register.simple_tag
def get(d, k1, k2):
    return d.get(k1, None).get(k2, None)


@register.filter
def get_topic(index):
    return topics[int(index)]


