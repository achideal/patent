from django.contrib import admin
from django.urls import path
import elasticGeoPoint.views as views

urlpatterns = [
    path("geoBox/", views.getGeoBox),
    path("geoBox/pageRefresh/", views.pageRefresh),
]
