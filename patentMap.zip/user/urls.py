# user\urls.py代码
from django.urls import path
from user import views

urlpatterns = [
    path('reg/', views.reg_view),
    path('login/', views.login_view),
    path('logout/', views.logout_view),
    path('mygrxx/', views.mygrxx_view),
]
