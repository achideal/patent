import re
import time

from django.contrib import messages
from django.core.mail import send_mail
from django.shortcuts import render
import hashlib
from django.http import HttpResponse, HttpResponseRedirect
import random

from patentSpatialSystem_version1 import settings
from user.models import User


# 用户的登录逻辑处理
def login_view(request):
    # 处理GET请求
    if request.method == 'GET':
        # 1, 首先检查session，判断用户是否第一次登录，如果不是，则直接重定向到首页
        if 'username' in request.session:  # request.session 类字典对象
            return HttpResponseRedirect('/patent')
        # 2, 然后检查cookie，是否保存了用户登录信息
        if 'username' in request.COOKIES:
            # 若存在则赋值回session，并重定向到首页
            request.session['username'] = request.COOKIES['username']
            return HttpResponseRedirect('/patent')
        # 不存在则重定向登录页，让用户登录
        return render(request, 'user/login.html')
    # 处理POST请求
    elif request.method == 'POST':
        print('*****************')
        username = request.POST.get('username')
        password = request.POST.get('password')
        m = hashlib.md5()
        m.update(password.encode())
        password_m = m.hexdigest()
        # 判断输入是否其中一项为空或者格式不正确
        if not username or username == '':
            username_error = '用户名或邮箱不为空 !'
            return render(request, 'user/login.html', locals())
        if not password:
            password_error = '密码不为空 !'
            return render(request, 'user/login.html', locals())
        # 若输入没有问题则进入数据比对阶段，看看已经注册的用户中是否存在该用户
        users = User.objects.filter(username=username, password=password_m)
        if not users:
            users = User.objects.filter(email=username, password=password_m)
        # 由于使用了filter, 所以返回值user是一个数组，但是也要考虑其为空的状态，即没有查到该用户
        if not users:
            password_error = '用户不存在或用户密码输入错误!!'
            return render(request, 'user/login.html', locals())
        # 返回值是个数组，并且用户名具备唯一索引，当前用户是该数组中第一个元素
        users = users[0]
        username = users.username
        email = users.email
        request.session['username'] = username
        request.session['email'] = email
        response = HttpResponseRedirect('/patent')
        # 检查post 提交的所有键中是否存在 isSaved 键
        if 'isSaved' in request.POST.keys():
            # 若存在则说明用户选择了记住用户名功能，执行以下语句设置cookie的过期时间
            response.set_cookie('username', username, 60 * 60 * 24 * 7)
            response.set_cookie('email', email, 60 * 60 * 24 * 7)
        else:
            # 若不存在则说明用户未选择记住用户名，cookie会话结束后过期
            response.set_cookie('username', username)
            response.set_cookie('email', email)
        return response


def reg_view(request):
    send_mail_flag = request.session.get('send_mail_flag', False)
    if send_mail_flag is True:
        verify_message = '验证码已发送，有效期10分钟，60s后可点击重新发送'

    # 用户注册逻辑代码
    if request.method == 'GET':
        return render(request, 'user/register.html')
    elif request.method == 'POST':
        # 处理提交数据
        username = request.POST.get('username')
        email = request.POST.get('email')
        form_verification_code = request.POST.get('form_verification_code')
        password_1 = request.POST.get('password_1')
        password_2 = request.POST.get('password_2')

        if "register" in request.POST:
            if not username:
                username_error = '请输入正确的用户名'
                return render(request, 'user/register.html', locals())
            # 可以设定密码格式，判断是都符合
            if not password_1 or not password_2:
                password_1_error = '请输入正确的密码'
                return render(request, 'user/register.html', locals())
            # 1 生成hash算法对象对密码进行加密
            m = hashlib.md5()
            # 2 对待加密明文使用update方法！要求输入明文为字节串
            m.update(password_1.encode())
            # 3 调用对象的 hexdigest[16进制],通常存16进制
            password_m1 = m.hexdigest()
            print(password_m1)  # 加密后的密文会显示在终端上
            # 对password_2执行MD5加密处理
            m = hashlib.md5()
            m.update(password_2.encode())
            password_m2 = m.hexdigest()
            print(password_m2)

            # 判断两次密码输入是否一致
            if password_m1 != password_m2:
                password_2_error = '两次密码不一致'
                return render(request, 'user/register.html', locals())

            # 查询用户名是否已注册过
            try:
                old_user = User.objects.get(username=username)
                # 当前用户名已被注册
                username_error = '用户已经被注册 !'
                return render(request, 'user/register.html', locals())
            except Exception as e:
                # 若没查到的情况下进行报错，则证明当前用户名可用
                print('%s是可用用户名--%s' % (username, e))
                if not re.match(r'^[a-z0-9][\w\.\-]*@[a-z0-9\-]+(\.[a-z]{2,5}){1,2}$', email):
                    email_error = '邮箱格式有误，请确认'
                    return render(request, 'user/register.html', locals())
                try:
                    old_email = User.objects.get(email=email)
                    # 当前邮箱已被注册
                    email_error = '该邮箱已被注册 ！'
                    return render(request, 'user/register.html', locals())
                except Exception as e:
                    # 若没查到的情况下进行报错，则证明当前邮箱可用
                    print('%s是可用邮箱--%s' % (email, e))

                    if form_verification_code == '':
                        verify_error = '验证码不应为空'
                        return render(request, 'user/register.html', locals())
                    # 验证码加密后对比 session中存放的 old_verification_code
                    m = hashlib.md5()
                    m.update(form_verification_code.encode())
                    verification_code = m.hexdigest()
                    old_verification_code = request.session.get('verification_code', None)
                    if verification_code != old_verification_code:
                        verify_error = '验证码不正确，请重新确认后提交'
                        return render(request, 'user/register.html', locals())
                    # 如果验证码对比正确，判断是否过期
                    verify_time = request.session.get('verify_time', None)
                    now_time = float(time.time())
                    verify_time = float(verify_time)
                    if now_time - verify_time > 600:
                        verify_error = '该验证码已过期，请重新获取'
                        return render(request, 'user/register.html', locals())

                    try:
                        user = User.objects.create(username=username, password=password_m1,
                                                   email=email)

                        messages.success(request, '恭喜您，注册成功！！！')
                        return render(request, 'user/register.html', locals())
                        # # 注册成功后
                        # html = '''
                        # 注册成功 点击<a href='/index/'>进入首页</a>
                        # '''
                        # # 存session
                        # request.session['username'] = username
                        # return HttpResponse(html)
                    # 若创建不成功会抛出异常
                    except Exception as e:
                        # 还可能存在用户名被重复使用的情况
                        print(e)
                        username_error = '该用户名已经被占用 '
                        email_error = '该邮箱已经被占用 ！'
                        return render(request, 'user/register.html', locals())

        elif "send_email" or "re_send_email" in request.POST:
            request.session['send_mail_flag'] = False
            username = request.POST.get('username')
            email = request.POST.get('email')
            form_verification_code = request.POST.get('form_verification_code')
            password_1 = request.POST.get('password_1')
            password_2 = request.POST.get('password_2')

            print('进入发送邮件程序')
            if not re.match(r'^[a-z0-9][\w\.\-]*@[a-z0-9\-]+(\.[a-z]{2,5}){1,2}$', email):
                email_error = '邮箱格式有误，请确认'
                return render(request, 'user/register.html', locals())
            try:
                old_email = User.objects.get(email=email)
                # 当前邮箱已被注册
                email_error = '该邮箱已被注册 ！'
                return render(request, 'user/register.html', locals())
            except Exception as e:
                # 若没查到的情况下进行报错，则证明当前邮箱可用
                print('%s是可用邮箱--%s' % (email, e))

                # 随机生成六位验证码
                verification_code = [0] * 6
                for i in range(len(verification_code)):
                    verification_code[i] = random.randint(0, 9)
                verification_code = [str(x) for x in verification_code]
                verification_code = "".join(verification_code)

                subject = 'patentMap用户注册验证码'  # 主题
                message = '您的验证码为:' + verification_code
                to_email = email
                from_email = settings.EMAIL_HOST_USER  # 发件人，在settings.py中已经配置
                # meg_html = '<a href="http://www.baidu.com">点击跳转</a>'  # 发送的是一个html消息 需要指定
                try:
                    send_mail(subject, message, from_email, [to_email])
                    # 邮件成功发送了,验证码加密后 存在session
                    m = hashlib.md5()
                    m.update(verification_code.encode())
                    verification_code = m.hexdigest()
                    request.session['verification_code'] = verification_code
                    request.session['verify_time'] = time.time()
                    request.session['send_mail_flag'] = True
                    verify_message = '验证码已发送，有效期10分钟，60s后可点击重新发送'
                    return render(request, 'user/register.html', locals())
                except Exception as e:
                    email_error = '无法给该邮箱发送验证码，请确认邮箱是否正确'
                    print('发送邮件失败！')
                    return render(request, 'user/register.html', locals())


def logout_view(request):
    # 实现退出功能
    # 删除session
    if 'username' in request.session:
        del request.session['username']
    if 'email' in request.session:
        del request.session['email']
    resp = HttpResponseRedirect('/patent')
    # 删除cookie
    if 'username' in request.COOKIES:
        resp.delete_cookie('username')
    if 'email' in request.COOKIES:
        resp.delete_cookie('email')
    return resp


# 用户空间的逻辑处理
def mygrxx_view(request):
    # 处理GET请求
    if request.method == 'GET':
        username = None
        # 1, 首先检查session，判断用户是否第一次登录
        if 'username' in request.session:  # request.session 类字典对象
            username = request.session['username']
        else:
            # 2, 然后检查cookie，是否保存了用户登录信息
            if 'username' in request.COOKIES:
                # 若存在则赋值回session，并重定向到首页
                request.session['username'] = request.COOKIES['username']
                username = request.session['username']
            else:
                # 均不存在则重定向登录页，让用户登录
                return HttpResponseRedirect('/user/login')

        # 若输入没有问题则进入数据比对阶段，看看已经注册的用户中是否存在该用户
        users = User.objects.filter(username=username)
        if not users:
            users = User.objects.filter(email=username)
        # 返回值是个数组，并且用户名具备唯一索引，当前用户是该数组中第一个元素
        users = users[0]
        username = users.username
        email = users.email
        create_time = users.create_time
        return render(request, 'user/mygrxx.html', locals())


