from django.contrib import admin
from django.urls import path
import allTopicModel.views as views

urlpatterns = [
    path('showOnePatent/topicOne/', views.topicOneWindow),
    path('showOnePatent/topicTwo/', views.topicTwoWindow),
]
