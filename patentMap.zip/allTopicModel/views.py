from django.shortcuts import render
from elasticGeoPoint import elastic
from allTopicModel import body, bodyAreaTopic2, bodyPoint
import json

# Create your views here.


def topicOneWindow(request):
    coords = None
    para = {}
    if request.GET["coords_global"]:
        coords = request.GET['coords_global']
        para["coords"] = json.dumps(coords, ensure_ascii=False)

    coords = json.loads(coords)  # 将Json string 转换为 dict
    flagOrPoint = coords['geometry']['coordinates'][0]

    if flagOrPoint == "onePoint":  # 查询一个点对应的专利清单
        onePoint = coords['geometry']['coordinates'][1]

        bodyPoint["query"]["bool"]["filter"]["geo_distance"]["locations.location"] = onePoint
        result = elastic.search(index='.ent-search-engine-documents-patent', body=bodyPoint)
        content = result["aggregations"]
        print("test:",content)
        return render(request, "allTopicModel/topicOne.html", content)
    else:
        points = flagOrPoint
        # 对获取的geoJson从elasticsearch拿数据
        body["query"]["bool"]["filter"]["geo_polygon"]["locations.location"]["points"] = points
        result = elastic.search(index='.ent-search-engine-documents-patent', body=body)

        content = result["aggregations"]

        return render(request, "allTopicModel/topicOne.html", content)




def topicTwoWindow(request):
    coords = None
    para = {}
    if request.GET["coords_global"]:
        coords = request.GET['coords_global']
        para["coords"] = json.dumps(coords, ensure_ascii=False)

    coords = json.loads(coords)  # 将Json string 转换为 dict
    flagOrPoint = coords['geometry']['coordinates'][0]

    if flagOrPoint == "onePoint":  # 查询一个点对应的专利清单
        onePoint = coords['geometry']['coordinates'][1]
        return render(request, "allTopicModel/topicOne.html")
    else:#查询一个区域
        points = flagOrPoint
        # 对获取的geoJson从elasticsearch拿数据
        bodyAreaTopic2["query"]["bool"]["filter"]["geo_polygon"]["locations.location"]["points"] = points
        result = elastic.search(index='.ent-search-engine-documents-patent', body=bodyAreaTopic2)
    content = result["aggregations"]["topic"]

    print(content)
    return render(request, "allTopicModel/worldcloud.html", content)
