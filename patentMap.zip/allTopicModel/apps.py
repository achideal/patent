from django.apps import AppConfig


class AlltopicmodelConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'allTopicModel'
