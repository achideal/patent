
body = {
    "size": 0,
    "query": {
        "bool": {
            "must": {
                "match_all": {}
            },
            "filter": {
                "geo_polygon": {
                    "locations.location": {
                        "points": []
                    }
                }
            }
        }
    },
    "aggs" :{
        "topic" :{
            "terms" :{
                "field" :"topicindex.enum",
                "size": 10,
                "order": {
                    "_count": "desc"
                },
                "collect_mode": "breadth_first"
            },
            "aggs" :{
                "year" :{
                    "terms" :{
                        "field" :"year.enum",
                        "size": 150,
                        "order": {
                            "_key": "desc"
                        }
                    }
                }
            }

        },
        "MaxYear": {
            "max": {
                "field": "year.float"
            }
        },
        "MinYear": {
            "min": {
                "field": "year.float"
            }
        }
    }
}

bodyPoint = {
  "size": 0,
  "query": {
    "bool": {
      "must": {
        "match_all": {}
      },
     "filter": {
        "geo_distance": {
          "distance": "200m",
          "locations.location": [-25.6671,37.7463 ]
        }
      }

    }
  },
"aggs" :{
        "topic" :{
            "terms" :{
                "field" :"topicindex.enum",
                "size": 10,
                "order": {
                    "_count": "desc"
                },
                "collect_mode": "breadth_first"
            },
            "aggs" :{
                "year" :{
                    "terms" :{
                        "field" :"year.enum",
                        "size": 150,
                        "order": {
                            "_key": "desc"
                        }
                    }
                }
            }

        },
        "MaxYear": {
            "max": {
                "field": "year.float"
            }
        },
        "MinYear": {
            "min": {
                "field": "year.float"
            }
        }
    }
}









bodyAreaTopic2 = {
  "size": 0,
  "query": {
    "bool": {
      "must": {
        "match_all": {}
      },
     "filter": {
        "geo_polygon": {
          "locations.location": {
            "points": []
          }
        }
      }
    }
  },
  "aggs":{
        "topic":{
            "terms":{
                "field":"topicindex.enum",
                "size": 235
            }
        }
  }
}
