from django.shortcuts import render,HttpResponse
from django.db.models import Q
from mainMap.utils.GenerateMainMap.GMAP import get_mainMap
from mainMap.models import PatentAssigneeLocation, LocationOrganization
from django.http import JsonResponse
from elasticGeoPoint import elastic, dslClosest
from mainMap import decideReturn,body_tra
from elasticGeoPoint.templatetags.myfilter import topics
import json

render_mainMap = get_mainMap()
# Create your views here.



def view_mainMap(request):
    render = render_mainMap
    return HttpResponse(render, content_type=None, status=None)

def view_patentList(request):
    request.encoding = 'utf-8'
    context = {}
    patent = None
    if request.GET['point_x'] and request.GET['point_y']:  # 判断不为空
        point_x = float(request.GET['point_x'])
        point_y = float(request.GET['point_y'])
        print("start")
        patent = PatentAssigneeLocation.objects.filter(Q(latitude=point_x) & Q(longitude=point_y)).values_list("title","date", "patent_id")  # values 是返回字典，value_list返回list
        print("end")
    context["patents"] = [{"title":title, "date":date, "patentID":patent_id} for title, date, patent_id in patent]
    print("now")
    return render(request, "listPatent/pointFirst.html", context)

def view_areaInfo(request):
    coords = None
    para = {}
    if request.GET["coords_global"]:
        coords = request.GET['coords_global']
        para["coords"] = json.dumps(coords, ensure_ascii=False)

    coords = json.loads(coords)  # 将Json string 转换为 dict
    flagOrPoint = coords['geometry']['coordinates'][0]

    if flagOrPoint == "onePoint":  # 查询一个点对应的专利清单
        onePoint = coords['geometry']['coordinates'][1]
        return render(request, "allTopicModel/topicOne.html")
    else:
        points = flagOrPoint
        # 对获取的geoJson从elasticsearch拿数据
        body_tra["query"]["bool"]["filter"]["geo_polygon"]["locations.location"]["points"] = points
        result = elastic.search(index='.ent-search-engine-documents-patent', body=body_tra)

    #print("-------------",result)
    content_year = result["aggregations"]["year"]["buckets"]


    years_topics = []
    locations =[]
    for y in content_year:
        temp = y["topic"]["buckets"]
        if temp: #大于1的要求一个点一个专利的不显示
            loca = temp[0]["location"]["buckets"][0]["key"].split(',')
            years_topics.append({"year": y["key"], "topic": topics[int(temp[0]["key"])]})
            locations.append((float(loca[0]), float(loca[1])))

    newDic = {}
    for key,value in zip(locations, years_topics):
        if key not in newDic.keys():
            newDic[key] = [value]
        else:
            newDic[key].append(value)


    response = {}
    response['qwe'] = 'Topic Analysis'
    response['routes'] = list(newDic.keys())
    response['topics_content'] = list(newDic.values())
    print(response)
    return JsonResponse(response)


def view_pointInfo(request):
    context = {}
    if request.GET['point_x'] and request.GET['point_y']:  # 判断不为空
        approximatePoint_x = float(request.GET['point_x'])
        approximatePoint_y = float(request.GET['point_y'])
        zoom = int(request.GET['zoom'])

        dslClosest["sort"][0]["_geo_distance"]["locations.location"] = [approximatePoint_y, approximatePoint_x]
        result = elastic.search(index='.ent-search-engine-documents-patent', body=dslClosest)
        for location in result['hits']['hits'][0]["_source"]["locations"]:
            latLong = location.split(',')

            point_x = float(latLong[0])
            point_y = float(latLong[1])
            if decideReturn([approximatePoint_x, approximatePoint_y], [point_x, point_y], zoom):
                organization = "Topic Analysis, Point"
                context['status'] = 1
                context['organization'] = organization
                context['point_x'] = point_x
                context['point_y'] = point_y
                return JsonResponse(context)

        context['status'] = 0
        print("这里没有点")
        return JsonResponse(context)





def show_one_patent(request):
    content = {}
    if request.GET['patentID']:
        patentID = request.GET['patentID']
    content['patentID'] = patentID
    return render(request, "onePatent/mainOnePatent.html", content)

def show_one_patent_information(request):
    content = {}
    patent = None
    if request.GET['patentID']:
        patentID = request.GET['patentID']
        patent = PatentAssigneeLocation.objects.filter(Q(patent_id=patentID)).values_list("title", "date")  # values 是返回字典，value_list返回list

    content['title'] = patent[0][0]  #因为返回的是list 所以多加了个索引
    content['date'] = patent[0][1]
    return render(request, "onePatent/infomationOnePatent.html", content)

def show_one_patent_kg(request):
    return render(request, "onePatent/kgOnePatent.html")