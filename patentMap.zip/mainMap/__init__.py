import math
from math import pi, sin, cos

addresses = [118.746795, 32.028986, 118.744657, 32.02933]
EARTH_REDIUS = 6378.137

def rad(d):
    return d * pi / 180.0

def geodistance(lng1,lat1,lng2,lat2):
    """ 根据两地的经纬度，计算对应的距离km"""
    radLat1 = rad(lat1)
    radLat2 = rad(lat2)
    a = radLat1 - radLat2
    b = rad(lng1) - rad(lng2)
    s = 2 * math.asin(math.sqrt(math.pow(math.sin(a / 2), 2) + math.cos(radLat1) * cos(radLat2) * math.pow(sin(b / 2), 2)))
    s = s * EARTH_REDIUS
    return s


def decideReturn(point1, point2, tier=1):
    states = [True, False]
    if tier <= 5 :
        return states[1]
    elif(tier == 6):
        if geodistance(point1[0],point1[1],point2[0],point2[1]) < 25:#km
            return states[0]
        else:
            return states[1]
    elif(tier == 7):
        if geodistance(point1[0],point1[1],point2[0],point2[1]) < 12:#km
            return states[0]
        else:
            return states[1]
    elif (tier == 8):
        if geodistance(point1[0], point1[1], point2[0], point2[1]) < 8:  # km
            return states[0]
        else:
            return states[1]
    elif(tier == 9):
        if geodistance(point1[0],point1[1],point2[0],point2[1]) < 5:#km
            return states[0]
        else:
            return states[1]
    elif (tier == 10):
        if geodistance(point1[0], point1[1], point2[0], point2[1]) < 3:  # km
            return states[0]
        else:
            return states[1]
    elif(tier == 11):
        if geodistance(point1[0],point1[1],point2[0],point2[1]) < 1:#km
            return states[0]
        else:
            return states[1]
    elif (tier == 12):
        if geodistance(point1[0], point1[1], point2[0], point2[1]) < 0.8:  # km
            return states[0]
        else:
            return states[1]
    elif(tier == 13):
        if geodistance(point1[0],point1[1],point2[0],point2[1]) < 0.3:#km
            return states[0]
        else:
            return states[1]
    elif (tier == 14):
        if geodistance(point1[0], point1[1], point2[0], point2[1]) < 0.15:  # km
            return states[0]
        else:
            return states[1]
    elif(tier == 15):
        if geodistance(point1[0],point1[1],point2[0],point2[1]) < 0.1:#km
            return states[0]
        else:
            return states[1]
    elif(tier == 16):
        if geodistance(point1[0],point1[1],point2[0],point2[1]) < 0.07:#km
            return states[0]
        else:
            return states[1]
    elif(tier == 17 or tier == 18):
        if geodistance(point1[0],point1[1],point2[0],point2[1]) < 0.05:#km
            return states[0]
        else:
            return states[1]




body_tra = {
  "size": 0,
  "query": {
    "bool": {
      "must": {
        "match_all": {}
      },
     "filter": {
        "geo_polygon": {
          "locations.location": {
            "points": []
          }
        }
      }
    }
  },
  "aggs":{
        "year":{
            "terms":{
                "field":"year.enum",
                "size": 50,
                "order": {
                  "_key": "asc"
                }
            },
             "aggs":{
                "topic":{
                    "terms":{
                          "field":"topicindex.enum",
                          "size": 1,
                          "order": {
                               "_count": "desc"
                           },
                           "collect_mode": "breadth_first"
                    },
                         "aggs":{
                            "location":{
                                "terms":{
                                      "field":"locations.enum",
                                      "size": 1,
                                      "order": {
                                           "_count": "desc"
                                       },
                                       "collect_mode": "breadth_first"
                                }
                            }
                }

                }
            }
        }
  }
}