import folium
from folium.plugins import FastMarkerCluster
from folium import plugins
from mainMap.models import PatentAssigneeLocation
from mainMap.utils.GenerateMainMap.static_value import draw_template, floatingWindows, myhost, customFigureTemplate


def get_mainMap():
    points = PatentAssigneeLocation.objects.exclude(latitude=None, longitude=None).values_list("latitude",
                                                                                               "longitude").distinct()  # 书写sql语句
    myMap = GMAP(points=points)
    render = myMap.cunstuct()
    print("进行初始化")

    return render


class GMAP():
    def __init__(self, points=[(0, 0)]):
        '''
        初始定义各种基本层
        '''
        self.figure = folium.Figure()

        tile_gaode = 'http://webrd02.is.autonavi.com/appmaptile?lang=zh_cn&size=1&scale=1&style=7&x={x}&y={y}&z={z}'#高德地图
        self.layer_Map = folium.Map(location=[0, 0], min_zoom=0, max_zoom=19, zoom_start=3, control=False,
                                    control_scale=True, prefer_canvas=True, tiles=None).\
                                    add_child(folium.TileLayer(tile_gaode, attr = "gaode", name ="高德")).\
                                    add_child(folium.TileLayer('openstreetmap')).\
                                    add_child(folium.TileLayer('Stamen Terrain', name="测试"))


        self.layer_minimap = plugins.MiniMap(folium.TileLayer(tile_gaode,attr="高德"), zoom_level_offset = -2, position='bottomright')

        self.layer_Draw = plugins.Draw(draw_options = {"circle": False, "polyline": False})
        self.layer_Draw._template = draw_template

        self.layer_FullScreen = plugins.Fullscreen()
        # self.layer_fastMakerCluster = FastMarkerCluster(points, name="All Points", callback=callback)

        self.layer_floatingWindow = folium.Element(floatingWindows)

        #最后修改figure的template
        mapName = self.layer_Map.get_name()
        self.figure._template = customFigureTemplate(mapName)

    def cunstuct(self):
        # 拼装map
        self.layer_Map.add_child(folium.raster_layers.WmsTileLayer('http://49.232.124.243:8080/geoserver/PatentMap/wms',layers='patent_point', fmt='image/png', transparent=True, name="Patent Assignee"))
        self.layer_Map.add_child(folium.raster_layers.WmsTileLayer('http://49.232.124.243:8080/geoserver/PatentMap/wms',layers='paper_institution', fmt='image/png', transparent=True, name="Paper Institution"))
        self.layer_Map.add_child(self.layer_Draw)
        self.layer_Map.add_child(self.layer_minimap)
        self.layer_Map.add_child(folium.LayerControl(position="bottomleft"))


        # 加入map到figure
        self.figure.add_child(self.layer_Map, name="myMainMap", index=1200)

        # 加入floatingWindow 到figure
        self.figure.html.add_child(self.layer_floatingWindow)
        self.figure.header.add_child(folium.CssLink(myhost + 'static/css/floatWindow.css'))
        self.figure.html.add_child(folium.JavascriptLink(myhost + 'static/js/floatWindow.js'))



        # 解析render 成HTML
        render = self.figure.get_root().render()

        return render
