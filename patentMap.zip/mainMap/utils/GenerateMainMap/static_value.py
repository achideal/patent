from jinja2 import Template

myhost = '/'


draw_template = Template(u"""
            {% macro script(this, kwargs) %}
                var options = {
                  position: {{ this.position|tojson }},
                  draw: {{ this.draw_options|tojson }},
                  edit: {{ this.edit_options|tojson }},
                }
                // FeatureGroup is to store editable layers.
                var drawnItems = new L.featureGroup().addTo(
                    {{ this._parent.get_name() }}
                );
                options.edit.featureGroup = drawnItems;
                var {{ this.get_name() }} = new L.Control.Draw(
                    options
                ).addTo( {{this._parent.get_name()}} );
                
                {{ this._parent.get_name() }}.on('draw:drawstart', function (e) {
                    {{ this._parent.get_name() }}.off('click', thisMapClick);
                });
               
               //定义绘制主题路径的函数
               var topicLines = L.featureGroup();
               var topicPopup = L.featureGroup();
               function draw_tra(route, content, color, layer){
                        for (i=0; i<route.length; i++){
                            
                            topicPopup.addLayer(L.popup({autoClose:false, closeOnClick:false, maxWidth:350}).setLatLng(route[i]).setContent("topic:" + JSON.stringify(content[i])).openOn(thisMap));
                        };
                        topicLine = new L.Polyline.AntPath(route, {
                          "delay": 800,
                          "dashArray": [
                            30,
                            31
                          ],
                          "weight": 7,
                          "color": color,
                          "pulseColor": "#FFFFFF",
                          "paused": false,
                          "reverse": false,
                          "hardwareAccelerated": true
                        });
                        topicLines.addLayer(topicLine);
                        
                        thisMap.addLayer(topicLine);
                        //绘制轨迹  
                    };
                function delete_tra(){
                    topicPopup.eachLayer(function (layer) {
                        layer.remove() });;
                    topicLines.eachLayer(function (layer) {
                        layer.remove() });;
                    notification.clear();
                }
               
               
                var coords_global = '0';
                {{ this._parent.get_name() }}.on(L.Draw.Event.CREATED, function(e) {
                    var layer = e.layer,
                        type = e.layerType;
                    var coords_Json = layer.toGeoJSON()
                    var coords = JSON.stringify(coords_Json);
                    var t = document.getElementById('id01');
                    var FW_head = document.getElementById('FW_head');
                    
             
                    
                    function click_Draw() {
                        coords_global = coords;
                        t.style.display = 'inline-block'; 
                        
                        var parentWindow = top.window;
                        var searchWindow = parentWindow.document.getElementById("mySidenav");
                        var left_iframe = parentWindow.document.getElementById("mySidenav_iframe");
                        left_iframe.src="/geoBox"+ '?coords_global=' + coords_global;
                        
                        document.getElementById('topicOne').src = "/showOnePatent/topicOne/"+ '?coords_global=' + coords_global;

                        
                        var httpRequest = new XMLHttpRequest();
                        url = 'areaInfo/' + '?coords_global=' + coords_global;
                        httpRequest.open('GET', url, true);
                        httpRequest.send();
                        
                        httpRequest.onreadystatechange = function () {
                        if (httpRequest.readyState == 4 && httpRequest.status == 200) {
                            var res = JSON.parse(httpRequest.responseText); //返回将字符串解析为Json
                            var json = httpRequest.responseText; 
                            FW_head.innerHTML = res.qwe;
                            routes = res.routes;
                            topics_content = res.topics_content;
                            
                            //绘制轨迹
                            color = "#000";
                            draw_tra(routes, topics_content, color, layer)
                            thisMap.flyToBounds(thisMap.fitBounds(routes));
                            //绘制轨迹
                            
                            
                            //通知绘制成功，并提供删除所有轨迹
                            notification.clear();
                            notification.success('Click <a onclick="delete_tra()" style="cursor: pointer; color: #000099">here</a> <p>to remove the trajectory</p>', 'Successfully generated the trajectory.',{
                                        timeout: 30000000,
                                        closable: true,
                                        dismissable: false,
                            });
                        }
                        };
                    };
                    //layer.on('click', click_Draw);
                    click_Draw(); //绘制完成后直接弹出窗口
                    
                    {{ this._parent.get_name() }}.once('click', function(e) {
                        {{ this._parent.get_name() }}.on('click', thisMapClick);
                    });//处理自动点击bug
                    
                    
                    drawnItems.addLayer(layer);
                 });
        
                {{ this._parent.get_name() }}.on('draw:created', function(e) {
                    drawnItems.addLayer(e.layer);
                });
                {% if this.export %}
                document.getElementById('export').onclick = function(e) {
                    var data = drawnItems.toGeoJSON();
                    var convertedData = 'text/json;charset=utf-8,'
                        + encodeURIComponent(JSON.stringify(data));
                    document.getElementById('export').setAttribute(
                        'href', 'data:' + convertedData
                    );
                    document.getElementById('export').setAttribute(
                        'download', {{ this.filename|tojson }}
                    );
                }
                {% endif %}
            {% endmacro %}
            """)



floatingWindows = '''<div id="id01" class="w3-modal">
    <div class="w3-modal-content w3-card-4 w3-animate-zoom">
        
        <header class="w3-container w3-blue">
            <!-- 右侧添加叉号 -->
            <span onclick="document.getElementById('id01').style.display='none'"
            class="w3-button w3-blue w3-xlarge w3-display-topright" style="padding: 0px; padding-right: 18px;">&times;</span>
            
            <!-- 右侧添隐藏按钮 -->
            <span id="hidebutton" onclick="toggleFloatWindow()"
            class="w3-button w3-blue w3-xlarge w3-display-topright" style="padding: 0px; margin-right: 50px;">&minus;</span>
            
            <!-- 左侧标题栏 -->
            <h3 id="FW_head" style="font-size: 18px; margin: 7.5px">Header</h3>
        </header>
        
        <div id="subplot">
            <div class="w3-bar w3-border-bottom">
                <button class="tablink w3-bar-item w3-button w3-light-grey" onclick="openCity(event, 'London')">TopicSeries</button>
                <button class="tablink w3-bar-item w3-button" onclick="openCity(event, 'Paris')">WordCloud</button>
                <button id="id01_button" onclick="openGeoList(coords_global)" style="background: steelblue;border-radius: 5px;border: none;color: white;margin-top: 4px;margin-left: 10px;width: 120px;">
                    Patent List
                </button>
            </div>
        
            <div id="London" class="w3-container city" style="height: 270px; padding: 0; display: block;">
                <iframe id="topicOne" style="height: 270px; width: 100%; border: medium none;" loading="lazy"></iframe>
            </div>
    
            <div id="Paris" class="w3-container city" style="display: none;">
                <p>wait next version! </p>
            </div>
        </div>
        
       
    </div>
</div>

</div>'''



#定制化folium.Figure的template
def customFigureTemplate(mapName):
    string_template = '''
        <!DOCTYPE html>\n
        <head>
        {% if this.title %}<title>{{this.title}}</title>{% endif %}
            {{this.header.render(**kwargs)}}\n
        <link rel="stylesheet" href="/static/css/leaflet-notifications.css">\n
        </head>\n
        <body>
            {{this.html.render(**kwargs)}}\n
        </body>\n
        <script src='/static/js/leaflet-ant-path.js'> </script>
        <script src='/static/js/leaflet-notifications.js'> </script>
        <script>
            {{this.script.render(**kwargs)}}\n
    ''' + '''
        var thisMap = {}
    '''.format(mapName) + '''
    //生成一个通知
    var notification = L.control
                    .notifications({
                        timeout: 3000,
                        position: 'topleft',
                        closable: true,
                        dismissable: true,
                        className: "customNotification",
                    })
                    .addTo(thisMap);
    $(".customNotification").attr('style',"position:fixed; left: 0; right: 0; text-align: -webkit-center; text-align-last:start");
    
    
    //修改draw的位置
    document.getElementsByClassName("leaflet-control-zoom")[0].style.marginTop = '60px';
    
    //设置地图鼠标点击事件
    function thisMapClick(e) 
    {
        var zoom = thisMap.getZoom();
        var approximatePoint_x = e.latlng.lat;
        var approximatePoint_y = e.latlng.lng;
        var point_x;
        var point_y;
        var status;
        var floatWindow = document.getElementById('id01');
        var httpRequest = new XMLHttpRequest();
        url = 'pointInfo/' + '?point_x=' + approximatePoint_x + '&point_y=' + approximatePoint_y + '&zoom=' + zoom;
        httpRequest.open('GET', url, true);
        httpRequest.send();
        httpRequest.onreadystatechange = function () 
        {
            if (httpRequest.readyState == 4 && httpRequest.status == 200) 
            {
                var res = JSON.parse(httpRequest.responseText);
                var json = httpRequest.responseText;
                status = res.status; 
                if (status == 1)
                {
                    document.getElementById('FW_head').innerHTML = 'Loading...,please wait!';
                    point_x = res.point_x;
                    point_y = res.point_y; //对浮动窗口的主题iframe进行更新,也要加入判断是否在一个范围内
                    coords_global = JSON.stringify({
                        'geometry' : {
                            'coordinates' : ['onePoint', [point_y, point_x]]
                        }
                    });
                    document.getElementById('topicOne').src = "/showOnePatent/topicOne/" + '?coords_global=' + coords_global;
                    var popup = L.popup() .setLatLng([point_x, point_y]) .setContent('<p>Hello!You just clicked here! <br />   (' + point_x + ',' + point_y + ')</p>') .openOn(thisMap);
                    //对浮动窗口标题进行更新
                    floatWindow.style.display = 'inline-block';
                    document.getElementById('FW_head').innerHTML = res.organization + '(' + point_x + ',' + point_y + ')';
                    //对侧边搜索窗口的src进行更新
                    var parentWindow = top.window;
                    var searchWindow = parentWindow.document.getElementById("mySidenav");
                    var left_iframe = parentWindow.document.getElementById("mySidenav_iframe");
                    left_iframe.src = "/geoBox" + '?coords_global=' + coords_global ;
                }
            }
        };
    };
    thisMap.on('click', thisMapClick);

    
    
    //设置左边搜索框和地图的交互
    function sleep(ms) {
      return new Promise(
        resolve => setTimeout(resolve, ms)
      );
    }
    async function SearchToMap(pointPosition){
        pointPosition = pointPosition.toString().split(',');
        thisMap.flyTo([Number(pointPosition[0]), Number(pointPosition[1])], 12);
        
        var popup = L.popup()
                            .setLatLng([Number(pointPosition[0]), Number(pointPosition[1])])
                            .setContent('<p>Positioning success!<br />Click to get details.</p>')
                            .openOn(thisMap);
    }
    </script>\n
    '''

    return Template(string_template)
