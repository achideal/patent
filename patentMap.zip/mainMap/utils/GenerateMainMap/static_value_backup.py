from jinja2 import Template

myhost = 'http://127.0.0.1:8000/'


draw_template = Template(u"""
            {% macro script(this, kwargs) %}
                var options = {
                  position: {{ this.position|tojson }},
                  draw: {{ this.draw_options|tojson }},
                  edit: {{ this.edit_options|tojson }},
                }
                // FeatureGroup is to store editable layers.
                var drawnItems = new L.featureGroup().addTo(
                    {{ this._parent.get_name() }}
                );
                options.edit.featureGroup = drawnItems;
                var {{ this.get_name() }} = new L.Control.Draw(
                    options
                ).addTo( {{this._parent.get_name()}} );
                
                var coords_global = 0;
                {{ this._parent.get_name() }}.on(L.Draw.Event.CREATED, function(e) {
                    var layer = e.layer,
                        type = e.layerType;
                    var coords = JSON.stringify(layer.toGeoJSON());
                    var t = document.getElementById('id01');
                    var FW_head = document.getElementById('FW_head');
                    layer.on('click', function() {
                        coords_global = coords;
                        t.style.display = 'inline-block'; 
                        var httpRequest = new XMLHttpRequest();
                        url = 'areaInfo/' + '?positionText=' + coords;
                        httpRequest.open('GET', url, true);
                        httpRequest.send();
                        
                        httpRequest.onreadystatechange = function () {
                        if (httpRequest.readyState == 4 && httpRequest.status == 200) {
                            var res = JSON.parse(httpRequest.responseText); 
                            var json = httpRequest.responseText; 
                            FW_head.innerHTML = res.qwe
                            console.log(json);  
                            }
                        };
                        console.log(coords);
                    });
                    drawnItems.addLayer(layer);
                 });
        
                {{ this._parent.get_name() }}.on('draw:created', function(e) {
                    drawnItems.addLayer(e.layer);
                });
                {% if this.export %}
                document.getElementById('export').onclick = function(e) {
                    var data = drawnItems.toGeoJSON();
                    var convertedData = 'text/json;charset=utf-8,'
                        + encodeURIComponent(JSON.stringify(data));
                    document.getElementById('export').setAttribute(
                        'href', 'data:' + convertedData
                    );
                    document.getElementById('export').setAttribute(
                        'download', {{ this.filename|tojson }}
                    );
                }
                {% endif %}
            {% endmacro %}
            """)

callback = ('function (row) {'
                    'var marker = L.marker(new L.LatLng(row[0], row[1]), {color: "red"});'
                    'var icon = L.AwesomeMarkers.icon({'
                    "icon: 'info-sign',"
                    "iconColor: 'white',"
                    "markerColor: 'green',"
                    "prefix: 'glyphicon',"
                    "extraClasses: 'fa-rotate-0'"
                    '});'
                    'marker.setIcon(icon);'
                    "var popup = L.popup({minWidth: '350', maxHeight: '350'});"
                    "const display_text = {point_x: row[0], point_y: row[1]};"
                    '''
                    var mytext = $(`<div id='mytext' class='display_text' style='width: 100.0%; height: 100.0%;'> 
                     <button id='point_btn' type=\"button\" 
                     onclick=\"
                     coords_global = JSON. stringify({'geometry': {'coordinates': ['onePoint',[${display_text.point_y}, ${display_text.point_x}]]} });
                     
                     var floatWindow = document.getElementById('id01');
                     document.getElementById('FW_head').innerHTML = 'Loading...,please wait!';
                     floatWindow.style.display = 'inline-block';
                        var httpRequest = new XMLHttpRequest();
                        url = 'pointInfo/' + '?point_x=${display_text.point_x}&point_y=${display_text.point_y}'
                        httpRequest.open('GET', url, true);
                        httpRequest.send();
                        
                        httpRequest.onreadystatechange = function () {
                        if (httpRequest.readyState == 4 && httpRequest.status == 200) {
                            var res = JSON.parse(httpRequest.responseText); 
                            var json = httpRequest.responseText; 
                            document.getElementById('FW_head').innerHTML = res.organization + '(${display_text.point_x}, ${display_text.point_y})';
                            console.log(json);  
                            }
                        };
                     \">Analysis of The Point</button>
                     <iframe style=\"width: 400px;\" frameborder=\"no\" src=\"/point/?point_x=${display_text.point_x}&point_y=${display_text.point_y}\">测试</iframe></div>`)[0];
                    '''
                    
                    "popup.setContent(mytext);"
                    "marker.bindPopup(popup);"
                    'return marker};')

floatingWindows = '''<div id="id01" class="w3-modal">
    <div class="w3-modal-content w3-card-4 w3-animate-zoom">
        <header class="w3-container w3-blue">
   <span onclick="document.getElementById('id01').style.display='none'"
         class="w3-button w3-blue w3-xlarge w3-display-topright">&times;</span>
            <h3 id="FW_head">Header</h3>
        </header>
        
        <div class="w3-bar w3-border-bottom">
            <button class="tablink w3-bar-item w3-button" onclick="openCity(event, 'London')">Topic</button>
            <button class="tablink w3-bar-item w3-button" onclick="openCity(event, 'Paris')">Topic2</button>
            <button id="id01_button" onclick="openGeoList(coords_global)>Patent List</button>
        </div>

        <div id="London" class="w3-container city">
            <p>The topic details for this area are shown here.</p>
            
        </div>

        <div id="Paris" class="w3-container city">
            <p>Here's a table</p>
        </div>
        
       
    </div>
</div>

</div>'''



#定制化folium.Figure的template
def customFigureTemplate(mapName):
    string_template = '''
        <!DOCTYPE html>\n
        <head>
        {% if this.title %}<title>{{this.title}}</title>{% endif %}
            {{this.header.render(**kwargs)}}\n
        </head>\n
        <body>
            {{this.html.render(**kwargs)}}\n
        </body>\n
        <script>
            {{this.script.render(**kwargs)}}\n
    ''' + '''
        var thisMap = {}
    '''.format(mapName) + '''
        
        function clickMap(){
            let centerX = document.body.clientWidth / 2 ;
            let centerY = document.body.clientHeight / 2 ;
            let elem = document.elementFromPoint(centerX, centerY);
            elem.click();
        }
        function sleep(ms) {
          return new Promise(
            resolve => setTimeout(resolve, ms)
          );
        }
        async function SearchToMap(pointPosition){
            pointPosition = pointPosition.toString().split(',');
            thisMap.setView([Number(pointPosition[0]), Number(pointPosition[1])], 3);
            await sleep(800);
            thisMap.setView([Number(pointPosition[0]), Number(pointPosition[1])], 5);
            await sleep(800);
            thisMap.setView([Number(pointPosition[0]), Number(pointPosition[1])], 8);
            await sleep(800);
            thisMap.setView([Number(pointPosition[0]), Number(pointPosition[1])], 11);
            await sleep(800);
            thisMap.setView([Number(pointPosition[0]), Number(pointPosition[1])], 15);
            
            setTimeout(clickMap, 1000);
        }
        </script>\n
    '''

    return Template(string_template)
