from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    path('mainMap/', views.view_mainMap),
    path('point/',views.view_patentList),

    #下面三个是单独打开一个网页的专利信息
    path('showOnePatent/', views.show_one_patent, name = 'showOnePatent'),
    path('showOnePatent/information', views.show_one_patent_information, name = 'showOnePatentInformation'),
    path('showOnePatent/kg', views.show_one_patent_kg, name = 'showOnePatentKG'),

    #下面是浮动窗口的专利信息
    path('mainMap/areaInfo/', views.view_areaInfo),
    path('mainMap/pointInfo/', views.view_pointInfo)


]
