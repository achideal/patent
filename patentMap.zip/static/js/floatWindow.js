


function openCity(evt, cityName) {
    var i, x, tablinks;
    x = document.getElementsByClassName("city");
    for (i = 0; i < x.length; i++) {
        x[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablink");
    for (i = 0; i < x.length; i++) {
        tablinks[i].classList.remove("w3-light-grey");
    }
    document.getElementById(cityName).style.display = "block";
    evt.currentTarget.classList.add("w3-light-grey");
}


function openGeoList(coords_global) {
    var parentWindow = top.window;
    var searchWindow = parentWindow.document.getElementById("mySidenav");
    var left_iframe = parentWindow.document.getElementById("mySidenav_iframe");

    left_iframe.src="/geoBox"+ '?coords_global=' + coords_global;
    if (searchWindow.style.width === '35%') {
        console.log("刷新成功");
    }
    else{
        parentWindow.document.getElementById("switchButton").click();
        left_iframe.src="/geoBox"+ '?coords_global=' + coords_global;
    }

}

function toggleFloatWindow(){
    var subpolt = document.getElementById("subplot");
    if(subplot.style.display != "none"){
        $("#subplot").hide(500,"linear");
        document.getElementById("hidebutton").innerHTML = '&plus;';
    }
    else{
        $("#subplot").show(500,"linear");
        document.getElementById("hidebutton").innerHTML = '&minus;';
    }
}


function removeTrajectory(){
    thisMap.removeLayer(antPolyline);
    notification.clear();
}

var antPolyline;

function MapDrawTra(route,color){

    antPolyline = new L.Polyline.AntPath(route, {
                      "delay": 800,
                      "dashArray": [
                        30,
                        31
                      ],
                      "weight": 7,
                      "color": color,
                      "pulseColor": "#FFFFFF",
                      "paused": false,
                      "reverse": false,
                      "hardwareAccelerated": true
                    });
    thisMap.addLayer(antPolyline);
    thisMap.flyToBounds(antPolyline.getBounds(), antPolyline.getBounds());
    notification.success('Click <a onclick="removeTrajectory()" style="cursor: pointer; color: #000099">here</a> <p>to remove the trajectory</p>', 'Successfully generated the trajectory.',{
                        timeout: 30000000,
                        closable: true,
                        dismissable: false,
                        });

}

