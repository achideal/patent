from django.contrib import admin
from django.urls import path
import homepage.views as views

urlpatterns = [
    path('', views.home),
    path("patent/", views.home),
]
